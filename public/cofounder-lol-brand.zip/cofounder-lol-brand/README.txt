cofounder.lol — Split mark brand kit
====================================

Two bars. A red gap. Two founders, one deal.

The mark is geometric — not a letter. Do not add a C, a monogram,
or extra icons inside the gap.


Files
-----
svg/
  split-mark.svg              Transparent mark (use on dark)
  split-mark-on-dark.svg      Mark on void (#080808) square
  split-mark-on-light.svg     Inverted mark on bone (#F4EFE6)
  wordmark.svg                Mark + cofounder.lol, transparent
  wordmark-on-dark.svg        Same, on void
  wordmark-on-light.svg       Same, inverted, on bone
  favicon.svg                 32×32 tab icon (void square)

png/
  split-mark-{16,32,64,128,256,512,1024}.png     Transparent
  split-mark-on-dark-{512,1024}.png
  split-mark-on-light-{512,1024}.png
  wordmark-on-dark.png
  wordmark-on-light.png
  app-icon-{192,512,1024}.png                    Padded mark on void
  avatar-400.png                                 Square social avatar
  favicon-16.png  favicon-32.png
  preview.png                                    This sheet

fonts/
  DMSans-Medium.ttf           Wordmark type (SIL Open Font License)
  OFL.txt


Color
-----
Void    #080808    background
Bone    #F4EFE6    mark bars (on dark), page paper
Stamp   #F2271D    the gap — the only accent
Ink     #0A0A0A    mark bars on light

Never recolor the gap. Never introduce a second accent.


Clear space
-----------
Keep empty space around the mark equal to the width of one bar
(the left rectangle). Do not crop into that margin.


Minimum size
------------
Mark       16 px  (favicon)
Wordmark   24 px tall
App icon   192 px


Do
--
- Use the SVG whenever you can
- Use the on-dark lockup on void / black / photo
- Use the on-light lockup on bone / white / paper
- Keep the gap red

Don't
-----
- Outline, glow, gradient, or drop-shadow the mark
- Rotate, skew, or add a container other than the square icon
- Set the bars in stamp red
- Place the transparent (bone) mark on a light field — use the ink version


Wordmark
--------
Type is DM Sans Medium. "cofounder" in bone (or ink on light).
".lol" is always stamp red. Outlined in the SVGs, so they open
in Figma / Illustrator without the font installed.
